# Shadow Cat: Kunai — Android APK project (v0.7)

В проект встроена текущая HTML-игра из версии 0.7. APK собирается через GitHub Actions.

## Как получить APK с телефона
1. Распакуй ZIP.
2. Создай новый репозиторий на GitHub (можно через браузер телефона).
3. Загрузи **все файлы и папки** из распакованного проекта в репозиторий. Важно: файл `.github/workflows/build-apk.yml` тоже должен попасть туда.
4. Открой вкладку **Actions** в репозитории.
5. Выбери **Build Shadow Cat APK** и нажми **Run workflow** (если workflow не запустился автоматически после загрузки).
6. Когда сборка закончится зелёным статусом, открой её страницу и скачай артефакт **ShadowCat-debug-apk**.
7. В ZIP артефакта находится `app-debug.apk`. Открой его на телефоне и, если Android спросит, разреши установку из этого источника.

Это debug APK для тестирования. Для публикации в Google Play понадобится отдельная release-сборка и подпись.

## Содержимое
- `app/src/main/assets/index.html` — сама игра (офлайн).
- `MainActivity.java` — Android WebView оболочка, fullscreen/portrait.
- Gradle конфигурация.
- GitHub Actions workflow для сборки APK.
